﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;

namespace BusinessLogic
{
    public class Voter
    {
        [Display(Name = "Vendor ID")]
        public int VoterID { get; set; }

        [Required]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LName { get; set; }

        [Display(Name = "Father Name")]
        public string FatherName { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        [Display(Name = "State")]
        public string State { get; set; }

        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Display(Name = "Phone")]
        [DataType(DataType.PhoneNumber)]
        public string Phone { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email ID")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "DOB")]
        public string DOB { get; set; }

        [Display(Name = "IssueDate")]
        public string IssueDate { get; set; }
    }

    public class Leader : Voter
    {
        [Required]
        [Display(Name = "Party Name")]
        [ForeignKey("PartyID")]
        public int PartyID { get; set; }

        [Display(Name = "Party Name")]
        public string PartyName { get; set; }

        [Required]
        [Display(Name = "Contest Name")]
        [ForeignKey("ContestID")]
        public int ContestID { get; set; }

        [Display(Name = "Contest Name")]
        public string ContestName { get; set; }
        public string PName { get; set; }
        public string ImgPath { get; set; }
        public string Result { get; set; }
        public int VoteCount { get; set; }

    }

    public class VoterLayer
    {
        public IEnumerable<Voter> Voter
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Voter> listVoter = new List<Voter>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllVoters", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Voter objVoter = new Voter();
                        objVoter.VoterID = Convert.ToInt32(reader["VoterID"]);
                        objVoter.FName = reader["FirstName"].ToString();
                        objVoter.LName = reader["LastName"].ToString();
                        objVoter.FatherName = reader["FatherName"].ToString();
                        objVoter.Address = reader["Address"].ToString();
                        objVoter.State = reader["State"].ToString();
                        objVoter.Gender = reader["Gender"].ToString();
                        objVoter.Phone = reader["Phone"].ToString();
                        objVoter.Email = reader["Email"].ToString();
                        objVoter.DOB = reader["DOB"].ToString();
                        objVoter.IssueDate = reader["IssueDate"].ToString();

                        listVoter.Add(objVoter);
                    }
                }
                return listVoter;
            }
        }

        public void EditVoter(Voter voter)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spUpdateVoter", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter UserID = new SqlParameter();
                UserID.ParameterName = "@UserID";
                UserID.Value = voter.VoterID;
                cmd.Parameters.Add(UserID);

                SqlParameter FName = new SqlParameter();
                FName.ParameterName = "@FirstName";
                FName.Value = voter.FName;
                cmd.Parameters.Add(FName);

                SqlParameter LName = new SqlParameter();
                LName.ParameterName = "@LastName";
                LName.Value = voter.LName;
                cmd.Parameters.Add(LName);

                SqlParameter FatherName = new SqlParameter();
                FatherName.ParameterName = "@FatherName";
                FatherName.Value = voter.FatherName;
                cmd.Parameters.Add(FatherName);

                SqlParameter StreetAddress = new SqlParameter();
                StreetAddress.ParameterName = "@StreetAddress";
                StreetAddress.Value = voter.Address;
                cmd.Parameters.Add(StreetAddress);

                SqlParameter State = new SqlParameter();
                State.ParameterName = "@State";
                State.Value = voter.State;
                cmd.Parameters.Add(State);

                SqlParameter Gender = new SqlParameter();
                Gender.ParameterName = "@Gender";
                Gender.Value = voter.Gender;
                cmd.Parameters.Add(Gender);

                SqlParameter Phone = new SqlParameter();
                Phone.ParameterName = "@Phone";
                Phone.Value = voter.Phone;
                cmd.Parameters.Add(Phone);

                SqlParameter Email = new SqlParameter();
                Email.ParameterName = "@Email";
                Email.Value = voter.Email;
                cmd.Parameters.Add(Email);

                SqlParameter DOB = new SqlParameter();
                DOB.ParameterName = "@DOB";
                DOB.Value = voter.DOB;
                cmd.Parameters.Add(DOB);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteVoter(int id)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spDeleteVoter", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter UserID = new SqlParameter();
                UserID.ParameterName = "@UserID";
                UserID.Value = id;
                cmd.Parameters.Add(UserID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<Leader> Leader
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Leader> listofLeaders = new List<Leader>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllLeaders", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Leader objLeader = new Leader();
                        objLeader.VoterID = Convert.ToInt32(reader["VoterID"]);
                        objLeader.FName = reader["FirstName"].ToString();
                        objLeader.LName = reader["LastName"].ToString();
                        objLeader.FatherName = reader["FatherName"].ToString();
                        objLeader.Address = reader["Address"].ToString();
                        objLeader.State = reader["State"].ToString();
                        objLeader.Gender = reader["Gender"].ToString();
                        objLeader.Phone = reader["Phone"].ToString();
                        objLeader.Email = reader["Email"].ToString();
                        objLeader.DOB = reader["DOB"].ToString();
                        objLeader.PartyName = reader["PartyName"].ToString();

                        listofLeaders.Add(objLeader);
                    }
                }
                return listofLeaders;
            }
        }

        public void EditLeader(Leader leader)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spUpdateLeader", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter UserID = new SqlParameter();
                UserID.ParameterName = "@UserID";
                UserID.Value = leader.VoterID;
                cmd.Parameters.Add(UserID);

                SqlParameter FName = new SqlParameter();
                FName.ParameterName = "@FirstName";
                FName.Value = leader.FName;
                cmd.Parameters.Add(FName);

                SqlParameter LName = new SqlParameter();
                LName.ParameterName = "@LastName";
                LName.Value = leader.LName;
                cmd.Parameters.Add(LName);

                SqlParameter FatherName = new SqlParameter();
                FatherName.ParameterName = "@FatherName";
                FatherName.Value = leader.FatherName;
                cmd.Parameters.Add(FatherName);

                SqlParameter StreetAddress = new SqlParameter();
                StreetAddress.ParameterName = "@StreetAddress";
                StreetAddress.Value = leader.Address;
                cmd.Parameters.Add(StreetAddress);

                SqlParameter State = new SqlParameter();
                State.ParameterName = "@State";
                State.Value = leader.State;
                cmd.Parameters.Add(State);

                SqlParameter Gender = new SqlParameter();
                Gender.ParameterName = "@Gender";
                Gender.Value = leader.Gender;
                cmd.Parameters.Add(Gender);

                SqlParameter Phone = new SqlParameter();
                Phone.ParameterName = "@Phone";
                Phone.Value = leader.Phone;
                cmd.Parameters.Add(Phone);

                SqlParameter Email = new SqlParameter();
                Email.ParameterName = "@Email";
                Email.Value = leader.Email;
                cmd.Parameters.Add(Email);

                SqlParameter DOB = new SqlParameter();
                DOB.ParameterName = "@DOB";
                DOB.Value = leader.DOB;
                cmd.Parameters.Add(DOB);

                SqlParameter PartyID = new SqlParameter();
                PartyID.ParameterName = "@PartyID";
                PartyID.Value = leader.PartyID;
                cmd.Parameters.Add(PartyID);

                SqlParameter ContestID = new SqlParameter();
                ContestID.ParameterName = "@ContestID";
                ContestID.Value = leader.ContestID;
                cmd.Parameters.Add(ContestID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteLeader(int id)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spDeleteLeader", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter UserID = new SqlParameter();
                UserID.ParameterName = "@UserID";
                UserID.Value = id;
                cmd.Parameters.Add(UserID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static int participantCount(int contest)
        {
            int count = 0;
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            using (conn)
            {
                SqlCommand command = new SqlCommand("spGetParticipantCount", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ContestID", contest);

                conn.Open();
                count = int.Parse(command.ExecuteScalar().ToString());
            }
            return count;
        }
    }
}
