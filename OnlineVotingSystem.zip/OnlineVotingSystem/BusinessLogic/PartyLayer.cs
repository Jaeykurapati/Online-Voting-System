﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace BusinessLogic
{

    public class Party
    {
        public int PartyID { get; set; }

        [Required]
        [Display(Name = "Party Name")]
        public string PartyName { get; set; }
        
        public string Path { get; set; }
        
        [Display(Name = "Established Date")]
        public string Date { get; set; }
        
        [Display(Name = "Party Logo")]
        public HttpPostedFileBase PhotoUpload { get; set; }
    }

    public class Contest
    {
        public int ContestID { get; set; }

        [Required]
        [Display(Name="Contest Name")]
        public string ContestName { get; set; }

        [Required]
        [Display(Name = "Status")]
        public string Status { get; set; }
        
        [Required]
        [Display(Name = "Start Time")]
        public string StartDateTime { get; set; }
        
        [Required]
        [Display(Name = "End Time")]
        public string EndDateTime { get; set; }

        public int UserID { get; set; }
        public int VoterID { get; set; }
    }

    public class PartyLayer
    {
        public IEnumerable<Party> Party
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Party> listofParties = new List<Party>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllParties", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Party objParty = new Party();
                        objParty.PartyID = Convert.ToInt32(reader["PartyID"]);
                        objParty.PartyName = reader["PartyName"].ToString();
                        objParty.Date = reader["EstDate"].ToString();
                        objParty.Path = reader["Path"].ToString();

                        listofParties.Add(objParty);
                    }
                }
                return listofParties;
            }
        }

        public void DeleteParty(int id)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spDeleteParty", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter PartyID = new SqlParameter();
                PartyID.ParameterName = "@PartyID";
                PartyID.Value = id;
                cmd.Parameters.Add(PartyID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public class ContestLayer 
    {
        public IEnumerable<Contest> Contest
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Contest> listofContests = new List<Contest>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllContests", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Contest objContest = new Contest();
                        objContest.ContestID = Convert.ToInt32(reader["ContestID"]);
                        objContest.ContestName= reader["ContestName"].ToString();
                        objContest.Status = reader["Status"].ToString();
                        objContest.StartDateTime = reader["StartDateTime"].ToString();
                        objContest.EndDateTime = reader["EndDateTime"].ToString();

                        listofContests.Add(objContest);
                    }
                }
                return listofContests;
            }
        }

        public void EditContest(Contest Contest)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spUpdateContest", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ContestID = new SqlParameter();
                ContestID.ParameterName = "@ContestID";
                ContestID.Value = Contest.ContestID;
                cmd.Parameters.Add(ContestID);

                SqlParameter ContestName = new SqlParameter();
                ContestName.ParameterName = "@ContestName";
                ContestName.Value = Contest.ContestName;
                cmd.Parameters.Add(ContestName);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteContest(int id)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spDeleteContest", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ContestID = new SqlParameter();
                ContestID.ParameterName = "@ContestID";
                ContestID.Value = id;
                cmd.Parameters.Add(ContestID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void StartContest(Contest Contest)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spStartContest", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ContestID = new SqlParameter();
                ContestID.ParameterName = "@ContestID";
                ContestID.Value = Contest.ContestID;
                cmd.Parameters.Add(ContestID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void EndContest(Contest Contest)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            SqlConnection con = new SqlConnection(connectionString);

            using (con)
            {
                SqlCommand cmd = new SqlCommand("spEndContest", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ContestID = new SqlParameter();
                ContestID.ParameterName = "@ContestID";
                ContestID.Value = Contest.ContestID;
                cmd.Parameters.Add(ContestID);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<Leader> ParticipantList(int ContestID)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
            List<Leader> listofContests = new List<Leader>();
            using (con)
            {
                SqlCommand cmd = new SqlCommand("spParticipantList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                SqlParameter parameter;
                parameter = cmd.Parameters.AddWithValue("@ContestID", ContestID);
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Leader objLeader = new Leader();
                    objLeader.ContestID = ContestID;
                    objLeader.VoterID = Convert.ToInt32(reader["UserID"]);
                    objLeader.FName = reader["FirstName"].ToString();
                    objLeader.LName = reader["LastName"].ToString();
                    objLeader.PName = reader["PartyName"].ToString();
                    objLeader.ImgPath = reader["ImagePath"].ToString();
                    listofContests.Add(objLeader);
                }
                con.Close();
            }
            return listofContests;
        }

        public IEnumerable<Contest> listOpenContest
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Contest> listofOpenContest = new List<Contest>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllOpenContests", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Contest objContest = new Contest();
                        objContest.ContestID = Convert.ToInt32(reader["ContestID"]);
                        objContest.ContestName = reader["ContestName"].ToString();
                        objContest.Status = reader["Status"].ToString();
                        objContest.StartDateTime = reader["StartDateTime"].ToString();

                        listofOpenContest.Add(objContest);
                    }
                }
                return listofOpenContest;
            }
        }

        public IEnumerable<Contest> listClosedContest
        {
            get
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
                List<Contest> listofClosedContest = new List<Contest>();
                using (con)
                {
                    SqlCommand cmd = new SqlCommand("spGetAllClosedContests", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Contest objContest = new Contest();
                        objContest.ContestID = Convert.ToInt32(reader["ContestID"]);
                        objContest.ContestName = reader["ContestName"].ToString();
                        objContest.Status = reader["Status"].ToString();
                        objContest.EndDateTime = reader["EndDateTime"].ToString();

                        listofClosedContest.Add(objContest);
                    }
                }
                return listofClosedContest;
            }
        }

        public IEnumerable<Leader> listLeaders(int ContestID)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString());
            List<Leader> listOfLeaders = new List<Leader>();
            using (con)
            {
                SqlCommand cmd = new SqlCommand("spContestResultList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                SqlParameter parameter;
                parameter = cmd.Parameters.AddWithValue("@ContestID", ContestID);
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Leader objContest = new Leader();
                    objContest.PartyID = Convert.ToInt32(reader["PartyID"]);
                    objContest.VoteCount = Convert.ToInt32(reader["VoteCount"]);
                    objContest.ContestName = reader["ContestName"].ToString();
                    objContest.FName = reader["FName"].ToString();
                    objContest.LName = reader["LName"].ToString();
                    objContest.PartyName = reader["PartyName"].ToString();
                    objContest.ImgPath = reader["ImgPath"].ToString();
                    objContest.Result = reader["Result"].ToString();

                    listOfLeaders.Add(objContest);
                }
                con.Close();
            }
            return listOfLeaders;
        }
    }
}
