﻿using BusinessLogic;
using OnlineVotingSystem.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineVotingSystem.Controllers
{
    [SessionAccess]
    public class VoterController : Controller
    {
        public static SqlConnection con;
        public static void connection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            con = new SqlConnection(connectionString);
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult openContestList()
        {
            ContestLayer objContest = new ContestLayer();
            List<Contest> listofOpenContests = objContest.listOpenContest.ToList();
            int RowCount = listofOpenContests.Count();
            ViewBag.Count = RowCount;
            return View(listofOpenContests);
        }

        [HttpGet]
        public ActionResult ParticipantList(int ID)
        {
            ContestLayer objContest = new ContestLayer();
            IEnumerable<Leader> listofPartcipants = objContest.ParticipantList(ID);
            int RowCount = listofPartcipants.Count();
            ViewBag.Count = RowCount;
            return View(listofPartcipants);
        }

        [HttpGet]
        public ActionResult CastMyVote(int id, int leaderid)
        {
            connection();
            SqlCommand com = new SqlCommand("spCheckVoterID", con);
            com.CommandType = CommandType.StoredProcedure;

            int UserID = (int)HttpContext.Session["UserID"];
            com.Parameters.AddWithValue("@ContestID", id);
            com.Parameters.AddWithValue("@VoterID", UserID);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = com.ExecuteReader();
                if (reader.HasRows)
                {
                    ViewBag.Message = "You have already voted for this contest!";
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("spAddVoterVote", con);
                    Leader leader = new Leader();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@VoterID", UserID);
                    cmd.Parameters.AddWithValue("@ContestID", id);
                    cmd.Parameters.AddWithValue("@UserID", leaderid);
                    
                    ViewBag.Success = "Thanks for voting!";
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception Err)
            {
                ViewBag.Failure = Err + "<h3>Something went wrong. Please check and try again!</h3>";
            }
            return View();
        }

        [HttpGet]
        public ActionResult completedContestList()
        {
            ContestLayer objContest = new ContestLayer();
            List<Contest> listofClosedContests = objContest.listClosedContest.ToList();
            int RowCount = listofClosedContests.Count();
            ViewBag.Count = RowCount;
            return View(listofClosedContests);
        }

        [HttpGet]
        public ActionResult ViewWinner(int ContestID)
        {
            ContestLayer objContest = new ContestLayer();
            IEnumerable<Leader> listofLeaders = objContest.listLeaders(ContestID);
            int RowCount = listofLeaders.Count();
            ViewBag.Count = RowCount;
            return View(listofLeaders);
        }
    }
}