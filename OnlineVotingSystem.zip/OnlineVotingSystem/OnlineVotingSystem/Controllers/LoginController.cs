﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OnlineVotingSystem.Models;
using System.Web.Security;
using BusinessLogic;

namespace OnlineVotingSystem.Controllers
{
    public class LoginController : Controller
    {
        string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();

        public ActionResult Login()
        {
            return View();
        }

        private DataTable AuthorizeLogin(string firstname, string password)
        {
            DataTable LoginData = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlDataAdapter SqlDataAdapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "spGetLoginDetails";
                cmd.Parameters.AddWithValue("@FirstName", firstname);
                cmd.Parameters.AddWithValue("@Password", password).Value = BusinessLogic.PasswordSHA.Hash(password);
                SqlDataAdapter.SelectCommand = cmd;
                SqlDataAdapter.Fill(LoginData);
            }
            return LoginData;
        }

        [HttpPost]
        public ActionResult Login(Models.Login loginDetails)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    UserDetails UserDetails = new UserDetails();
                    DataTable DataTable = new DataTable();
                    DataTable = AuthorizeLogin(loginDetails.FirstName, loginDetails.Password);
                    UserDetails.UserID = int.Parse(DataTable.Rows[0][0].ToString());
                    UserDetails.FirstName = DataTable.Rows[0][1].ToString();
                    UserDetails.Password = DataTable.Rows[0][2].ToString();
                    UserDetails.RoleID = int.Parse(DataTable.Rows[0][3].ToString());
                    UserDetails.RoleName = DataTable.Rows[0][4].ToString();
                    Session["UserID"] = UserDetails.UserID;
                    Session["FirstName"] = UserDetails.FirstName;
                    Session["RoleID"] = UserDetails.RoleID;

                    if (Session["FirstName"] != null) 
                    {
                        if (UserDetails.RoleName == "Admin")
                        {
                            return RedirectToAction("Index", "Home");
                        }
                        else if (UserDetails.RoleName == "Voter")
                        {
                            return RedirectToAction("Index", "Voter");
                        }
                    }
                    else 
                    {
                        RedirectToAction("Login", "Login");
                    }
                }
            }
            catch (Exception) 
            {
                ViewBag.Message = "Incorrect First Name (or) Password! Please try again";
            }
            return View();
        }
    }
}