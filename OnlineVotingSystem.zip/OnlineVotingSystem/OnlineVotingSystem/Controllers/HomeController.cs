﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLogic;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web.Hosting;
using System.Web.Security;
using OnlineVotingSystem.Models;

namespace OnlineVotingSystem.Controllers
{
    [SessionAccess]
    public class HomeController : Controller
    {
        public static SqlConnection con;
        public static void connection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OnlineVoting"].ToString();
            con = new SqlConnection(connectionString);
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult VoterList() 
        {
            VoterLayer objVoter = new VoterLayer();
            List<Voter> listVoter = objVoter.Voter.ToList();
            int RowCount = listVoter.Count();
            ViewBag.Count = RowCount;
            return View(listVoter);
        }

        [HttpGet]
        public ActionResult AddVoter() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddVoter(Voter voter)
        {
            if (ModelState.IsValid)
            {
                connection();
                SqlCommand com = new SqlCommand("spCheckEmail", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Email", voter.Email);
                SqlDataReader reader;
                try
                {
                    con.Open();
                    reader = com.ExecuteReader();
                    if (reader.HasRows)
                    {
                        ViewBag.EmailCheck = "Voter already exists!";
                        con.Close();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("spAddVoter", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@FName", voter.FName);
                        cmd.Parameters.AddWithValue("@Password", voter.Password).Value = BusinessLogic.PasswordSHA.Hash(voter.Password);
                        cmd.Parameters.AddWithValue("@LName", voter.LName);
                        cmd.Parameters.AddWithValue("@FatherName", voter.FatherName);
                        cmd.Parameters.AddWithValue("@Address", voter.Address);
                        cmd.Parameters.AddWithValue("@State", voter.State);
                        cmd.Parameters.AddWithValue("@Gender", voter.Gender);
                        cmd.Parameters.AddWithValue("@Phone", voter.Phone);
                        cmd.Parameters.AddWithValue("@Email", voter.Email);
                        cmd.Parameters.AddWithValue("@DOB", voter.DOB);
                        ViewBag.Success = voter.FName + " has been added to Voters Database";
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                catch (Exception Err)
                {
                    ViewBag.Failure = Err + "<h3>Something went wrong. Please check and try again!</h3>";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult EditVoter(int id) 
        {
            VoterLayer objVoter = new VoterLayer();
            Voter voter = objVoter.Voter.Single(v => v.VoterID == id);
            return View(voter);
        }

        [HttpPost]
        public ActionResult EditVoter(Voter voter) 
        {
            VoterLayer objVoter = new VoterLayer();
            objVoter.EditVoter(voter);
            return RedirectToAction("VoterList");
        }

        [HttpGet]
        public ActionResult DeleteVoter(int id)
        {
            VoterLayer objVoter = new VoterLayer();
            objVoter.DeleteVoter(id);
            return RedirectToAction("VoterList");
        }

        [HttpGet]
        public ActionResult AddParty() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddParty(HttpPostedFileBase uploadFile, BusinessLogic.Party party)
        {
            if (uploadFile != null && uploadFile.ContentLength > 0)
            {
                string filePath = Path.Combine(Server.MapPath("~/Content/Images/PartyLogo"), Path.GetFileName(uploadFile.FileName));
                string fileExtension = Path.GetExtension(uploadFile.FileName);

                if (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".bmp" || fileExtension.ToLower() == ".gif" ||
                    fileExtension.ToLower() == ".png")
                {
                    uploadFile.SaveAs(filePath);
                    connection();
                    SqlCommand com = new SqlCommand("spCheckParty", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@PartyName", party.PartyName);
                    SqlDataReader reader;
                    try
                    {
                        con.Open();
                        reader = com.ExecuteReader();
                        if (reader.HasRows)
                        {
                            ViewBag.Message = "Party already exists! Please try again . . .";
                            con.Close();
                        }
                        else
                        {
                            SqlCommand cmd = new SqlCommand("spAddParty", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@PartyName", party.PartyName);
                            cmd.Parameters.AddWithValue("@Path", "~/Content/Images/PartyLogo/" + uploadFile.FileName);
                            ViewBag.Message = party.PartyName + " has been added to Party Database";
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    catch (Exception Err)
                    {
                        ViewBag.Message = Err + "<h3>Something went wrong. Please check and try again!</h3>";
                    }
                }
                else
                {
                    ViewBag.Message = "Upload only image files with extensions - .jpg, .gif, .bmp, .png";
                }
            }
            else 
            {
                ViewBag.Message = "Please select a Party Logo";
            }
            return View();
        }

        [HttpGet]
        public ActionResult PartyList()
        {
            PartyLayer objParty = new PartyLayer();
            List<BusinessLogic.Party> listofParties = objParty.Party.ToList();
            int RowCount = listofParties.Count();
            ViewBag.Count = RowCount;
            return View(listofParties);
        }

        [HttpGet]
        public ActionResult DeleteParty(int id)
        {
            PartyLayer objParty = new PartyLayer();
            objParty.DeleteParty(id);
            return RedirectToAction("PartyList");
        }

        public IEnumerable<Party> GetPartyList
        {
            get
            {
                PartyLayer objParty = new PartyLayer();
                IEnumerable<Party> listofParties = objParty.Party.ToList();
                return listofParties;
            }
        }

        public IEnumerable<Contest> GetContestList
        {
            get
            {
                ContestLayer objContest = new ContestLayer();
                IEnumerable<Contest> listofContests = objContest.Contest.ToList();
                return listofContests;
            }
        }

        [HttpGet]
        public ActionResult AddContestent()
        {
            ViewBag.Parties = GetPartyList;
            ViewBag.Contests = GetContestList;
            return View();
        }

        [HttpPost]
        public ActionResult AddContestent(Leader Leader)
        {
            connection();
            SqlCommand com = new SqlCommand("spCheckEmail", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Email", Leader.Email);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = com.ExecuteReader();
                if (reader.HasRows)
                {
                    ViewBag.Message = "Leader already exists!";
                    con.Close();
                }
                else
                {

                    SqlCommand cmd = new SqlCommand("spAddLeader", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FName", Leader.FName);
                    cmd.Parameters.AddWithValue("@LName", Leader.LName);
                    cmd.Parameters.AddWithValue("@FatherName", Leader.FatherName);
                    cmd.Parameters.AddWithValue("@Address", Leader.Address);
                    cmd.Parameters.AddWithValue("@State", Leader.State);
                    cmd.Parameters.AddWithValue("@Gender", Leader.Gender);
                    cmd.Parameters.AddWithValue("@Phone", Leader.Phone);
                    cmd.Parameters.AddWithValue("@Email", Leader.Email);
                    cmd.Parameters.AddWithValue("@DOB", Leader.DOB);
                    cmd.Parameters.AddWithValue("@PartyID", Leader.PartyID);
                    cmd.Parameters.AddWithValue("@ContestID", Leader.ContestID);
                    ViewBag.Message = Leader.FName + " has been added to Leaders Database";
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception Err)
            {
                ViewBag.Message = Err + "<h3>Something went wrong. Please check and try again!</h3>";
            }
            ViewBag.Parties = GetPartyList;
            ViewBag.Contests = GetContestList;
            return View();
        }

        [HttpGet]
        public ActionResult LeaderList()
        {
            VoterLayer objLeader = new VoterLayer();
            List<Leader> listofLeaders = objLeader.Leader.ToList();
            int RowCount = listofLeaders.Count();
            ViewBag.Count = RowCount;
            return View(listofLeaders);
        }

        [HttpGet]
        public ActionResult EditLeader(int id)
        {
            VoterLayer objLeader = new VoterLayer();
            Leader leader = objLeader.Leader.Single(v => v.VoterID == id);
            ViewBag.Parties = GetPartyList;
            ViewBag.Contests = GetContestList;
            return View(leader);
        }

        [HttpPost]
        public ActionResult EditLeader(Leader leader)
        {
            VoterLayer objLeader = new VoterLayer();
            objLeader.EditLeader(leader);
            return RedirectToAction("LeaderList");
        }

        [HttpGet]
        public ActionResult DeleteLeader(int id)
        {
            VoterLayer objLeader = new VoterLayer();
            objLeader.DeleteLeader(id);
            return RedirectToAction("LeaderList");
        }

        [HttpGet]
        public ActionResult AddContest()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddContest(Contest contest)
        {
            connection();
            SqlCommand com = new SqlCommand("spCheckContest", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ContestName", contest.ContestName);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = com.ExecuteReader();
                if (reader.HasRows)
                {
                    ViewBag.UserMessage = "Contest already exists!";
                    con.Close();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("spAddContest", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ContestName", contest.ContestName);
                    ViewBag.Message = contest.ContestName + " is added to Database!";
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception Err)
            {
                ViewBag.Message = Err + "<h3>Something went wrong. Please check and try again!</h3>";
            }
            return View();
        }

        [HttpGet]
        public ActionResult ContestList()
        {
            ContestLayer objContest = new ContestLayer();
            List<Contest> listofContests = objContest.Contest.ToList();
            int RowCount = listofContests.Count();
            ViewBag.Count = RowCount;
            return View(listofContests);
        }

        [HttpGet]
        public ActionResult EditContest(int id)
        {
            ContestLayer objContest = new ContestLayer();
            Contest contest = objContest.Contest.Single(v => v.ContestID == id);
            return View(contest);
        }

        [HttpPost]
        public ActionResult EditContest(Contest contest)
        {
            ContestLayer objContest = new ContestLayer();
            objContest.EditContest(contest);
            return RedirectToAction("ContestList");
        }

        [HttpGet]
        public ActionResult DeleteContest(int id)
        {
            ContestLayer objContest = new ContestLayer();
            objContest.DeleteContest(id);
            return RedirectToAction("ContestList");
        }

        [HttpGet]
        public ActionResult StartContest(int id)
        {
            ContestLayer objContest = new ContestLayer();
            Contest contest = objContest.Contest.Single(v => v.ContestID == id);
            return View(contest);
        }

        [HttpPost]
        public ActionResult StartContest(Contest contest)
        {
            ContestLayer objContest = new ContestLayer();
            objContest.StartContest(contest);
            return RedirectToAction("ContestList"); 
        }

        [HttpGet]
        public ActionResult EndContest(int id)
        {
            ContestLayer objContest = new ContestLayer();
            Contest contest = objContest.Contest.Single(v => v.ContestID == id);
            return View(contest);
        }

        [HttpPost]
        public ActionResult EndContest(Contest contest)
        {
            ContestLayer objContest = new ContestLayer();
            objContest.EndContest(contest);
            return RedirectToAction("ContestList");
        }

        [HttpGet]
        public ActionResult ParticipantList(int ID)
        {
            ContestLayer objContest = new ContestLayer();
            IEnumerable<Leader> listofPartcipants = objContest.ParticipantList(ID);
            int RowCount = listofPartcipants.Count();
            ViewBag.Count = RowCount;
            return View(listofPartcipants);
        }

        public ActionResult Logout() 
        {
            Session.Abandon();
            return RedirectToAction("Login", "Login");
        }
	}
}