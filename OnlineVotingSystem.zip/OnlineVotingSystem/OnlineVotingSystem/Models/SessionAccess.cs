﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineVotingSystem.Models
{
    public class SessionAccessAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            if (HttpContext.Current.Session["UserID"] == null)
            {
                actionContext.Result = new RedirectResult("~/Login/Login");
            }
        }
    }
}